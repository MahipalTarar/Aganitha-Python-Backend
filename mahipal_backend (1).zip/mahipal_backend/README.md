# PubMed Papers Fetcher

## Overview
This project provides a command-line tool to fetch research papers from PubMed based on a user-specified query, filter for papers with at least one author affiliated with a pharmaceutical or biotech company, and output the results as a CSV file.

## Features
- Fetches papers using the PubMed API
- Filters for non-academic (pharma/biotech) authors
- Outputs results as CSV or to console
- Typed Python codebase
- Poetry for dependency management
- Modular code: reusable module + CLI

## Setup
1. **Install Poetry:**
   ```sh
   curl -sSL https://install.python-poetry.org | python3 -
   ```
2. **Install dependencies:**
   ```sh
   poetry install
   ```

## Usage

Run the CLI with:
```sh
poetry run get-papers-list "your pubmed query here" --file results.csv
```

### Command-line Options

- `query` (required): The PubMed query string (in quotes if it contains spaces).
- `-h`, `--help`: Show usage instructions.
- `-d`, `--debug`: Print debug information during execution.
- `-f`, `--file FILENAME`: Specify the filename to save the results as a CSV. If not provided, output is printed to the console.

### Examples

**Write results to a file:**
```sh
poetry run get-papers-list "cancer immunotherapy" --file results.csv
```

**Print results to the console:**
```sh
poetry run get-papers-list "cancer immunotherapy"
```

**Show debug information:**
```sh
poetry run get-papers-list "cancer immunotherapy" --debug
```

**Show help:**
```sh
poetry run get-papers-list --help
```

### Sample Output

| PubmedID  | Title                  | Publication Date | Non-academic Author(s) | Company Affiliation(s) | Corresponding Author Email |
|-----------|------------------------|------------------|------------------------|------------------------|---------------------------|
| 12345678  | Sample Paper Title     | 2024-06-01       | John Doe               | Acme Biotech           | john.doe@acmebio.com      |

## Code Organization
- `papers_fetcher/`: Core logic and data models
- `cli/`: Command-line interface

## Tools Used
- [Poetry](https://python-poetry.org/)
- [Requests](https://docs.python-requests.org/) (for HTTP requests)
- [PubMed API](https://www.ncbi.nlm.nih.gov/books/NBK25501/)

## Publishing
- The module can be published to Test PyPI for bonus points.

## Notes
- Heuristics for non-academic authors are implemented in `papers_fetcher/filters.py`.
- All code is type-annotated and modular. 